"""Entry point for running the package directly with python -m code_error_detector."""

from code_error_detector.cli import main

if __name__ == "__main__":
    main()
